package com.wing.folderplayer.utils

data class LyricLine(
    val timeMs: Long,
    val text: String
)
