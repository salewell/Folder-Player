package com.wing.folderplayer.ui.player

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.wing.folderplayer.service.MusicService
import com.wing.folderplayer.data.prefs.PlaybackPreferences
import com.wing.folderplayer.ui.browser.SourceConfig
import com.wing.folderplayer.ui.browser.SourceType
import com.wing.folderplayer.data.repo.PlayerRepository
import com.wing.folderplayer.data.source.LocalSource
import com.wing.folderplayer.utils.LrcParser
import com.wing.folderplayer.utils.LyricLine
import com.wing.folderplayer.utils.CueParser
import com.wing.folderplayer.utils.CueTrack
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File // Assuming Local Source needs File, but we should use Source interface generally

data class PlayerUiState(
    val currentTitle: String = "No Song Playing",
    val currentArtist: String = "",
    val coverUri: Any? = null,
    val isPlaying: Boolean = false,
    val progress: Float = 0f,
    val duration: Long = 0L,
    val currentPosition: Long = 0L,
    val lyrics: List<LyricLine> = emptyList(),
    val currentLyricIndex: Int = -1,
    val currentMediaId: String? = null,
    val currentFolderName: String = "",
    val audioInfo: String = "",
    val shuffleModeEnabled: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,

    val playlist: List<androidx.media3.common.MediaItem> = emptyList(),
    val coverDisplaySize: String = "STANDARD", // STANDARD or LARGE
    val autoNextFolder: Boolean = false,
    
    // Buffering state
    val isBuffering: Boolean = false,
    val bufferedPosition: Long = 0L
)

class PlayerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val exceptionHandler = kotlinx.coroutines.CoroutineExceptionHandler { _, throwable ->
        android.util.Log.e("PlayerViewModel", "Coroutine failure", throwable)
    }

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var mediaControllerFuture: ListenableFuture<MediaController>? = null
    private var player: Player? = null

    // For demo purposes, we will initialize the repository here
    private val repository = PlayerRepository()
    private val localSource = LocalSource()
    
    private var metadataJob: kotlinx.coroutines.Job? = null
    private val lyricsCache = mutableMapOf<String, List<LyricLine>>()
    
    // Keep track of current source for lyrics and cover loading
    private var currentSource: com.example.folderplayer.data.source.MusicSource? = null
    private var currentFolderPath: String? = null
    private var currentSourceConfig: SourceConfig? = null
    private var playbackPreferences: PlaybackPreferences? = null
    private var sourcePreferences: com.example.folderplayer.data.prefs.SourcePreferences? = null
    private var lyricPreferences: com.example.folderplayer.data.prefs.LyricPreferences? = null
    private var isRestoring = false

    fun initializeController(context: Context) {
        if (playbackPreferences == null) {
            playbackPreferences = PlaybackPreferences(context)
        }
        if (sourcePreferences == null) {
            sourcePreferences = com.example.folderplayer.data.prefs.SourcePreferences(context)
        }
        if (lyricPreferences == null) {
            lyricPreferences = com.example.folderplayer.data.prefs.LyricPreferences(context)
        }
        
        // Restore cached UI state immediately for instant feedback
        val lastMediaId = playbackPreferences?.getLastMediaId()
        playbackPreferences?.getCachedMetadata()?.let { cached ->
             _uiState.value = _uiState.value.copy(
                 currentTitle = cached.title,
                 currentArtist = cached.artist,
                 currentFolderName = cached.folderName,
                 audioInfo = cached.audioInfo,
                 coverUri = cached.coverUri,
                 lyrics = cached.lyrics.toList(),
                 currentMediaId = lastMediaId
             )
             
             // Also seed the lyrics cache to prevent re-fetching
             if (lastMediaId != null && cached.lyrics.isNotEmpty()) {
                 lyricsCache[lastMediaId] = cached.lyrics.toList()
             }
        }
        
        // Load initial cover size and auto next folder setting
        val size = playbackPreferences?.getCoverDisplaySize() ?: "STANDARD"
        val autoNext = playbackPreferences?.getAutoNextFolder() ?: false
        _uiState.value = _uiState.value.copy(
            coverDisplaySize = size,
            autoNextFolder = autoNext
        )

        val sessionToken = SessionToken(context, ComponentName(context, MusicService::class.java))
        mediaControllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        mediaControllerFuture?.addListener({
            try {
                val controller = mediaControllerFuture?.get() ?: return@addListener
                player = controller
                setupPlayerListener()
                updatePlaybackState()
                
                // 1. Sync internal variables FROM PREFS first
                syncInternalStateFromPrefs()

                // 2. High-precision Restoration Detection
                val lastMediaId = playbackPreferences?.getLastMediaId()
                val playerMediaId = controller.currentMediaItem?.mediaId
                val playerState = controller.playbackState
                val isPlaying = controller.isPlaying
                
                // We restore if:
                // a) The player is totally empty or idle.
                // b) The player has items, but the ID doesn't match our 'last saved' ID, 
                //    AND it's not currently playing (don't interrupt active music).
                if (lastMediaId != null) {
                    val isPlayerEmpty = controller.mediaItemCount == 0
                    val isMismatched = playerMediaId != lastMediaId
                    val isInterrupted = !isPlaying && playerState != Player.STATE_READY
                    
                    if (isPlayerEmpty || (isMismatched && isInterrupted)) {
                        isRestoring = true
                        android.util.Log.d("PlayerViewModel", "Detected state drift or cold start. Restoring last known song: $lastMediaId")
                    }
                }

                // 3. Initial sync
                updateMetadata() 
                
                if (isRestoring) {
                    restoreLastState()
                }
            } catch (e: Exception) {
                android.util.Log.e("PlayerViewModel", "MediaController Init Error", e)
                _error.value = "Playback System Failed to Initialize"
            }
        }, MoreExecutors.directExecutor())
    }

    private fun restoreLastState() {
        val prefs = playbackPreferences ?: return
        val config = prefs.getLastSourceConfig() ?: return
        val folderPath = prefs.getLastFolderPath() ?: return
        val mediaId = prefs.getLastMediaId()
        val position = prefs.getLastPosition()

        if (mediaId == null) return

        viewModelScope.launch(exceptionHandler) {
            // Check if we were playing a CUE track
            if (mediaId.contains("#track_")) {
                // Determine cuePath: usually base name of the audio file referenced in ID
                val audioPath = mediaId.substringBefore("#")
                // Try .cue with same name as audio
                val cuePath = audioPath.substringBeforeLast(".") + ".cue"
                
                playCueSheetInternal(config, cuePath, mediaId, position, playWhenReady = false)
            } else if (mediaId.lowercase().endsWith(".cue")) {
                playCueSheetInternal(config, mediaId, null, position, playWhenReady = false)
            } else {
                playFolderInternal(config, folderPath, mediaId, position, playWhenReady = false)
            }
        }
    }

    private fun syncInternalStateFromPrefs() {
        val prefs = playbackPreferences ?: return
        val config = prefs.getLastSourceConfig() ?: return
        val folderPath = prefs.getLastFolderPath() ?: return
        
        // Reconstruct source
        currentSourceConfig = config
        currentFolderPath = folderPath
        currentSource = when (config.type) {
            com.example.folderplayer.ui.browser.SourceType.LOCAL -> localSource
            com.example.folderplayer.ui.browser.SourceType.WEBDAV -> {
                com.example.folderplayer.data.source.WebDavAuthManager.setCredentials(config.username, config.password)
                com.example.folderplayer.data.source.WebDavSource(config.url, config.username, config.password)
            }
        }
    }

    private fun setupPlayerListener() {
        player?.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // When we transition to a new item, cancel any existing metadata work
                // to prevent older song data from 'flickering' in
                metadataJob?.cancel()
                updateMetadata()
                
                // If we transition to null and were at the end, it might be the end of the folder
                if (mediaItem == null && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                    checkAndPlayNextFolder()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    checkAndPlayNextFolder()
                }
                // Update buffering state
                val buffering = playbackState == Player.STATE_BUFFERING
                _uiState.value = _uiState.value.copy(isBuffering = buffering)
                updatePlaybackState()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlaybackState()
                if (isPlaying) {
                    startProgressLoop()
                    // Re-check metadata after 1.5 seconds to catch bitrates that populate after buffering
                    viewModelScope.launch(exceptionHandler) {
                        kotlinx.coroutines.delay(1500)
                        updateMetadata()
                    }
                }
            }
            
            override fun onEvents(player: Player, events: Player.Events) {
                if (events.contains(Player.EVENT_MEDIA_METADATA_CHANGED) || 
                    events.contains(Player.EVENT_TRACKS_CHANGED) ||
                    events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED) ||
                    events.contains(Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED) ||
                    events.contains(Player.EVENT_REPEAT_MODE_CHANGED)) {
                    updateMetadata()
                }
            }
        })
    }

    private fun startProgressLoop() {
        viewModelScope.launch(exceptionHandler) {
            while (player?.isPlaying == true) {
                updatePlaybackState()
                kotlinx.coroutines.delay(200) // Update every 200ms
            }
        }
    }

    private fun updateMetadata() {
        player?.let { p ->
             val currentMediaItem = p.currentMediaItem
             val metadata = p.mediaMetadata
             val currentTitleFromMetadata = metadata.title?.toString()

             // Guard: If we have an item but NO title yet, the service is still parsing metadata.
             // We MUST NOT overwrite the UI with "No Song Playing" if we are restoring or buffering.
             if (currentMediaItem != null && currentTitleFromMetadata.isNullOrBlank()) {
                 if (isRestoring || p.playbackState == Player.STATE_BUFFERING || p.playbackState == Player.STATE_IDLE) {
                     return@let
                 }
             }

             // Only once we have a real media item AND a valid title, or if we've truly given up,
             // do we clear the restoration flag.
             if (currentMediaItem != null && !currentTitleFromMetadata.isNullOrBlank()) {
                 isRestoring = false
             }

             // Guard: If we have NO media item at all, don't immediately overwrite the UI on startup/transitions.
             if (currentMediaItem == null) {
                 if (isRestoring || p.playbackState == Player.STATE_BUFFERING || p.playbackState == Player.STATE_IDLE) {
                     return@let
                 }
             }

             val items = mutableListOf<MediaItem>()
             for (i in 0 until p.mediaItemCount) {
                 items.add(p.getMediaItemAt(i))
             }

             val mediaId = currentMediaItem?.mediaId
             val folderName = cleanFolderName(mediaId)
             val rawTitle = metadata.title?.toString() ?: "No Song Playing"
             val cleanTitle = rawTitle.substringBeforeLast('.')
             
             // Path validation: Check if this song actually belongs to our current directory context
             val belongsToCurrentFolder = mediaId != null && currentFolderPath != null && 
                                          mediaId.contains(currentFolderPath!!)
             
             // If we are NOT restoring, and the player is playing something we didn't expect,
             // we should update our context to match the player (reactive behavior).
             if (!isRestoring && mediaId != null && !belongsToCurrentFolder) {
                 // Update internal context to match reality in the player
                 val extractedParent = if (mediaId.contains("#track_")) {
                     mediaId.substringBefore("#").substringBeforeLast('/')
                 } else {
                     mediaId.substringBeforeLast('/')
                 }
                 if (extractedParent.isNotEmpty() && extractedParent.startsWith("http")) {
                     currentFolderPath = extractedParent
                 }
             }
             
             // Extract audio format info from tracks
             var audioInfo = ""
             for (groupIndex in 0 until p.currentTracks.groups.size) {
                 val group = p.currentTracks.groups[groupIndex]
                 if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO) {
                     // Grab info from the first track in the group even if not selected
                     val format = group.getTrackFormat(0)
                     val mime = format.sampleMimeType?.lowercase() ?: ""
                     val displayFormat = when {
                         mime.contains("flac") -> "FLAC"
                         mime.contains("alac") || mime.contains("apple") && mime.contains("lossless") -> "ALAC"
                         mime.contains("mpeg") || mime.contains("mp3") -> "MP3"
                         mime.contains("ogg") || mime.contains("vorbis") -> "OGG"
                         mime.contains("opus") -> "OPUS"
                         mime.contains("aac") -> "AAC"
                         mime.contains("mp4") || mime.contains("m4a") -> "M4A"
                         else -> {
                             val ext = p.currentMediaItem?.mediaMetadata?.extras?.getString("file_ext")
                             val fallback = ext?.uppercase()?.take(4) ?: p.currentMediaItem?.mediaId?.substringAfterLast('.')?.uppercase()?.take(4) ?: "AUDIO"
                             if (mime.isNotEmpty()) "$fallback ($mime)" else fallback
                         }
                     }

                     var bitrateStr = if (format.bitrate > 0) "${format.bitrate / 1000}kbps" else ""
                     var sampleRate = format.sampleRate
                     var channelCount = format.channelCount
                     
                     // Fallback 1: Local MediaMetadataRetriever
                     if (bitrateStr.isEmpty() || sampleRate <= 0 || channelCount <= 0) {
                         val path = p.currentMediaItem?.mediaId?.let { 
                             if (it.startsWith("file://")) it.substring(7) else if (it.startsWith("/") && !it.startsWith("http")) it else null
                         }
                         if (path != null && java.io.File(path).exists()) {
                             try {
                                 val retriever = android.media.MediaMetadataRetriever()
                                 retriever.setDataSource(path)
                                 val b = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE)
                                 if (b != null) {
                                     bitrateStr = "${b.toInt() / 1000}kbps"
                                 }
                                 
                                 if (sampleRate <= 0) {
                                     val sr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)
                                     if (sr != null) {
                                         sampleRate = sr.toInt()
                                     }
                                 }
                                 retriever.release()
                             } catch (e: Exception) { e.printStackTrace() }
                         }
                     }

                     // Fallback 2: Calculate from file size and duration
                     if (bitrateStr.isEmpty() && p.duration > 0) {
                         val fileSize = p.currentMediaItem?.mediaMetadata?.extras?.getLong("file_size", 0L) ?: 0L
                         if (fileSize > 0) {
                             val durationSec = p.duration / 1000.0
                             var bitrateCalc = ((fileSize * 8) / durationSec) / 1000.0
                             
                             // MP3 specific cap (metadata often inflates calculation)
                             val ext = p.currentMediaItem?.mediaMetadata?.extras?.getString("file_ext") ?: ""
                             if (ext.equals("mp3", ignoreCase = true) && bitrateCalc > 320) {
                                 bitrateCalc = 320.0
                             }

                             val standards = listOf(
                                 32.0, 40.0, 48.0, 56.0, 64.0, 80.0, 96.0, 112.0, 128.0, 160.0, 
                                 192.0, 224.0, 256.0, 320.0, 448.0, 500.0, 640.0, 700.0, 800.0, 
                                 900.0, 1000.0, 1100.0, 1200.0, 1411.0
                             )
                             
                             // Find the closest standard bitrate if within a reasonable margin (10%)
                             val closest = standards.minByOrNull { Math.abs(it - bitrateCalc) } ?: bitrateCalc
                             val snapped = if (Math.abs(closest - bitrateCalc) < (bitrateCalc * 0.1)) closest else bitrateCalc
                             
                             bitrateStr = "${snapped.toInt()}kbps"
                         }
                     }

                     val samplerate = if (sampleRate > 0) {
                         val rate = sampleRate / 1000.0
                         if (rate % 1 == 0.0) "${rate.toInt()}kHz" else "${String.format("%.1f", rate)}kHz"
                     } else ""
                     
                     // Channels omitted as requested
                     
                     audioInfo = listOfNotNull(
                         displayFormat,
                         bitrateStr.ifEmpty { null },
                         samplerate.ifEmpty { null }
                     ).joinToString(" | ")
                     break
                 }
             }
             
             // Immediate (FAST) Update: Update title, cover, and folder name synchronously
             // so the UI reacts instantly to a song change without any coroutine delay.
             val currentArtistImmediate = metadata.artist?.toString() ?: ""
             val targetMediaId = p.currentMediaItem?.mediaId
             
             _uiState.value = _uiState.value.copy(
                 currentTitle = cleanTitle,
                 currentArtist = currentArtistImmediate,
                 currentFolderName = folderName,
                 coverUri = metadata.artworkUri ?: metadata.artworkData,
                 audioInfo = audioInfo, // Partial info if bitrate fallback is slow
                 isPlaying = p.isPlaying,
                 currentMediaId = targetMediaId,
                 playlist = items
             )

             metadataJob?.cancel()
             metadataJob = viewModelScope.launch(exceptionHandler) {
                  // DEEP Update: Load lyrics and perform potentially slow bit-rate fallbacks
                  
                  // Only reload lyrics if they aren't for the current media ID or are empty
                  val lyrics = if (lyricsCache.containsKey(targetMediaId) && lyricsCache[targetMediaId]?.isNotEmpty() == true) {
                      lyricsCache[targetMediaId] ?: emptyList()
                  } else {
                      val loaded = loadLyrics(targetMediaId, cleanTitle, currentArtistImmediate, metadata)
                      if (targetMediaId != null) lyricsCache[targetMediaId] = loaded
                      loaded
                  }

                  // Final check to ensure we are still on the same song before applying state
                  if (p.currentMediaItem?.mediaId != targetMediaId) return@launch

                  _uiState.value = _uiState.value.copy(
                    lyrics = lyrics,
                    duration = p.duration.takeIf { it > 0 } ?: 1L,
                    shuffleModeEnabled = p.shuffleModeEnabled,
                    repeatMode = p.repeatMode
                  )
                  
                  // Save for next restart (instant cache)
                  playbackPreferences?.saveCachedMetadata(
                      com.example.folderplayer.data.prefs.CachedMetadata(
                          title = cleanTitle,
                          artist = currentArtistImmediate,
                          folderName = folderName,
                          audioInfo = audioInfo,
                          coverUri = metadata.artworkUri?.toString(), // Only save external URI strings
                          lyrics = lyrics.toTypedArray()
                      )
                  )
                  
                  // Save playback state
                  if (!isRestoring && p.playbackState != Player.STATE_IDLE) {
                      playbackPreferences?.savePlaybackState(
                          currentSourceConfig,
                          currentFolderPath,
                          targetMediaId,
                          p.currentPosition
                      )
                  }
              }
        }
    }

    fun toggleShuffle() {
        player?.let { p ->
            p.shuffleModeEnabled = !p.shuffleModeEnabled
            _uiState.value = _uiState.value.copy(shuffleModeEnabled = p.shuffleModeEnabled)
        }
    }

    fun toggleRepeatMode() {
        player?.let { p ->
            val nextMode = when (p.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
                else -> Player.REPEAT_MODE_OFF
            }
            p.repeatMode = nextMode
            _uiState.value = _uiState.value.copy(repeatMode = p.repeatMode)
        }
    }

    fun toggleAutoNextFolder() {
        val nextValue = !_uiState.value.autoNextFolder
        _uiState.value = _uiState.value.copy(autoNextFolder = nextValue)
        playbackPreferences?.saveAutoNextFolder(nextValue)
    }

    private fun checkAndPlayNextFolder() {
        if (!_uiState.value.autoNextFolder) return
        
        // We only move to next folder if repeat mode is OFF or ALL (not ONE)
        // Usually if it's ALL, it will loop the current folder, so it will never reach STATE_ENDED.
        // If it's OFF, it reaches STATE_ENDED.
        
        viewModelScope.launch(exceptionHandler) {
            moveNextFolder()
        }
    }

    private suspend fun moveNextFolder() {
        val config = currentSourceConfig ?: return
        val currentPath = currentFolderPath ?: return
        val source = currentSource ?: return
        
        // 1. Determine parent path
        val parentPath = if (currentPath.contains("/")) {
            currentPath.substringBeforeLast('/')
        } else {
            "" // Root
        }
        
        // 2. List siblings (folders in the same parent)
        val siblings = withContext(Dispatchers.IO) {
            try {
                source.list(parentPath)
            } catch (e: Exception) {
                emptyList()
            }
        }.filter { it.isDirectory }
        
        if (siblings.isEmpty()) return
        
        // 3. Apply sorting using SourcePreferences
        val sortOption = sourcePreferences?.getDirectorySort(parentPath) ?: sourcePreferences?.getDefaultSort() ?: com.example.folderplayer.data.prefs.SourcePreferences.SortOption("NAME", true)
        
        val sortedSiblings = when (sortOption.field) {
            "NAME" -> {
                if (sortOption.ascending) siblings.sortedBy { it.name.lowercase() }
                else siblings.sortedByDescending { it.name.lowercase() }
            }
            "DATE" -> {
                if (sortOption.ascending) siblings.sortedBy { it.lastModified }
                else siblings.sortedByDescending { it.lastModified }
            }
            "SIZE" -> {
                if (sortOption.ascending) siblings.sortedBy { it.size }
                else siblings.sortedByDescending { it.size }
            }
            else -> siblings.sortedBy { it.name.lowercase() }
        }
        
        // Find current folder in sorted siblings
        val currentIndex = sortedSiblings.indexOfFirst { it.path == currentPath || it.path == "$currentPath/" || it.path.trimEnd('/') == currentPath.trimEnd('/') }
        
        if (currentIndex != -1 && currentIndex < sortedSiblings.size - 1) {
            val nextFolder = sortedSiblings[currentIndex + 1]
            playFolderInternal(config, nextFolder.path, null, 0L, playWhenReady = true)
        }
    }

    private fun cleanFolderName(path: String?): String {
        if (path == null) return ""
        try {
            val decodedPath = java.net.URLDecoder.decode(path, "UTF-8")
            val parts = decodedPath.split('/', '\\').filter { it.isNotEmpty() }
            if (parts.size < 2) return "Root"
            
            // parts.last() is typically the filename (e.g., Song.mp3)
            // The segment before it is the folder
            val folderIndex = parts.size - 2
            val folderPart = parts[folderIndex]
            val cleanFolder = cleanString(folderPart)
            
            // If the folder name is very short (e.g., "CD1"), prepend the parent folder
            if (cleanFolder.length <= 6 && folderIndex >= 1) {
                val parentPart = parts[folderIndex - 1]
                return "${cleanString(parentPart)} - $cleanFolder"
            }
            return cleanFolder
        } catch (e: Exception) {
            // Fallback: extract the part before the last slash
            val trimmed = path.substringBeforeLast('/')
            return trimmed.substringAfterLast('/').ifEmpty { "Music" }
        }
    }

    private fun cleanString(input: String): String {
        return input
            .replace(Regex("\\{.*?\\}"), "") // Remove {...}
            .replace(Regex("\\[.*?\\]"), "") // Remove [...]
            .replace(Regex("(?i)\\s+flac"), "") // Remove " FLAC" (case insensitive)
            .replace(Regex("\\s+"), " ") // Collapse multiple spaces
            .trim()
    }

    private fun extractEmbeddedLyrics(metadata: androidx.media3.common.MediaMetadata): String? {
        // Media3 often puts unrecognized tags into extras
        val extras = metadata.extras
        if (extras != null) {
            // Check common keys used by various extractors
            return extras.getString("lyrics") 
                ?: extras.getString("lyric")
                ?: extras.getString("text")
        }
        return null
    }

    private suspend fun loadLyrics(
        mediaId: String?, 
        title: String, 
        artist: String?,
        metadata: androidx.media3.common.MediaMetadata? = null
    ): List<LyricLine> {
        if (mediaId == null || currentSource == null) return emptyList()
        return withContext(Dispatchers.IO) {
            try {
                // 1. Try .lrc file in the same directory (Highest Priority)
                val lrcPath = mediaId.substringBeforeLast('.') + ".lrc"
                val lrcContent = currentSource?.readText(lrcPath)
                if (lrcContent != null) {
                    val parsed = LrcParser.parse(lrcContent)
                    if (parsed.isNotEmpty()) return@withContext parsed
                }
                
                // 2. Try Embedded lyrics (Priority 2)
                metadata?.let { m ->
                    val embedded = extractEmbeddedLyrics(m)
                    if (!embedded.isNullOrBlank()) {
                        val parsed = LrcParser.parse(embedded)
                        if (parsed.isNotEmpty()) return@withContext parsed
                    }
                }

                // 3. Try Lyric API (Priority 3)
                val apiUrl = lyricPreferences?.getLyricApiUrl()
                
                val url = apiUrl
                if (url != null && title != "No Song Playing") {
                    val apiLrc = com.example.folderplayer.data.network.LyricApi.fetchLyrics(url, title, artist)
                    if (apiLrc != null) {
                        val parsed = LrcParser.parse(apiLrc)
                        if (parsed.isNotEmpty()) return@withContext parsed
                    }
                }

                emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    fun updatePlaybackState() {
        player?.let { p ->
            val position = p.currentPosition
            val duration = p.duration.takeIf { it > 0 } ?: 1L
            val lyrics = _uiState.value.lyrics
            // Find current lyric index
            val index = lyrics.indexOfLast { it.timeMs <= position }

            _uiState.value = _uiState.value.copy(
                currentPosition = position,
                duration = duration,
                progress = position.toFloat() / duration,
                isPlaying = p.isPlaying,
                currentLyricIndex = index,
                bufferedPosition = p.bufferedPosition
            )

            // Periodically save position (every 5 seconds)
            if (!isRestoring && Math.abs(position - (playbackPreferences?.getLastPosition() ?: 0L)) > 5000) {
                playbackPreferences?.savePosition(position)
            }
        }
    }

    fun playPause() {
        player?.let { p ->
            if (p.isPlaying) p.pause() else p.play()
            updatePlaybackState()
        }
    }

    fun previous() {
        player?.seekToPreviousMediaItem()
    }

    fun next() {
        player?.seekToNextMediaItem()
    }
    
    fun seekTo(positionMs: Long) {
        player?.seekTo(positionMs)
        updatePlaybackState()
    }

    fun seekTo(position: Float) {
        player?.let { p ->
            val duration = p.duration
            if (duration > 0) {
                p.seekTo((position * duration).toLong())
                updatePlaybackState()
            }
        }
    }

    fun playAt(index: Int) {
        player?.seekTo(index, 0L)
        player?.play()
    }

    // Demo function to simulate playing a folder
    // Updated to support SourceConfig
    fun playFolder(sourceConfig: com.example.folderplayer.ui.browser.SourceConfig, path: String, startingFileUri: String? = null) {
        // Immediately set pending state for visual feedback
        val pendingTitle = startingFileUri?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Loading..."
        val pendingFolder = path.substringAfterLast('/').let { 
            try { java.net.URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it } 
        }
        _uiState.value = _uiState.value.copy(
            currentTitle = pendingTitle,
            currentFolderName = pendingFolder,
            coverUri = null,
            lyrics = emptyList(),
            isBuffering = true,
            progress = 0f,
            currentPosition = 0L,
            duration = 0L
        )
        
        viewModelScope.launch(exceptionHandler) {
            playFolderInternal(sourceConfig, path, startingFileUri, 0L, playWhenReady = true)
        }
    }

    fun playCustomList(sourceConfig: SourceConfig, files: List<com.example.folderplayer.data.source.MusicFile>, startIndex: Int) {
        viewModelScope.launch(exceptionHandler) {
            val source = when (sourceConfig.type) {
                com.example.folderplayer.ui.browser.SourceType.LOCAL -> {
                    com.example.folderplayer.data.source.WebDavAuthManager.clear()
                    localSource
                }
                com.example.folderplayer.ui.browser.SourceType.WEBDAV -> {
                     com.example.folderplayer.data.source.WebDavAuthManager.setCredentials(sourceConfig.username, sourceConfig.password)
                     com.example.folderplayer.data.source.WebDavSource(sourceConfig.url, sourceConfig.username, sourceConfig.password)
                }
            }
            
            // Reconstruct internal state
            currentSource = source
            val folderPath = files.getOrNull(startIndex)?.path?.substringBeforeLast('/') ?: ""
            currentFolderPath = folderPath
            currentSourceConfig = sourceConfig
            
            // Try to find cover for this batch (assuming same folder)
            val coverUri = repository.findCover(source, folderPath)

            val mediaItems = files.map { file ->
                repository.createMediaItem(file.name, source.getUri(file.path), coverUri, null, file.size)
            }
            player?.setMediaItems(mediaItems)
            if (startIndex in mediaItems.indices) {
                player?.seekTo(startIndex, 0L)
            }
            player?.prepare()
            player?.play()
            
            // Save state
            playbackPreferences?.savePlaybackState(sourceConfig, currentFolderPath, files.getOrNull(startIndex)?.path, 0L)
            
            // Force metadata update after a delay
            kotlinx.coroutines.delay(1000)
            updateMetadata()
        }
    }

    fun playCueSheet(sourceConfig: SourceConfig, cuePath: String) {
        // Immediately set pending state for visual feedback
        val pendingTitle = cuePath.substringAfterLast('/').substringBeforeLast('.')
        val pendingFolder = cuePath.substringBeforeLast('/').substringAfterLast('/').let { 
            try { java.net.URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it } 
        }
        _uiState.value = _uiState.value.copy(
            currentTitle = pendingTitle,
            currentFolderName = pendingFolder,
            coverUri = null,
            lyrics = emptyList(),
            isBuffering = true,
            progress = 0f,
            currentPosition = 0L,
            duration = 0L
        )
        
        viewModelScope.launch(exceptionHandler) {
            playCueSheetInternal(sourceConfig, cuePath, null, 0L, playWhenReady = true)
        }
    }

    private suspend fun playCueSheetInternal(
        sourceConfig: SourceConfig, 
        cuePath: String, 
        startingMediaId: String?, 
        positionMs: Long, 
        playWhenReady: Boolean
    ) {
        val source = when (sourceConfig.type) {
            com.example.folderplayer.ui.browser.SourceType.LOCAL -> {
                com.example.folderplayer.data.source.WebDavAuthManager.clear()
                localSource
            }
            com.example.folderplayer.ui.browser.SourceType.WEBDAV -> {
                 com.example.folderplayer.data.source.WebDavAuthManager.setCredentials(sourceConfig.username, sourceConfig.password)
                 com.example.folderplayer.data.source.WebDavSource(sourceConfig.url, sourceConfig.username, sourceConfig.password)
            }
        }
        
        val cueContent = source.readText(cuePath) ?: return
        val (referencedFile, tracks) = CueParser.parse(cueContent)
        if (tracks.isEmpty()) return

        val parentPath = cuePath.substringBeforeLast('/', "")
        var audioPath: String? = null
        
        // 1. Try the file referenced in the BUG sheet
        if (referencedFile != null) {
            val p = if (parentPath.isEmpty()) referencedFile else "$parentPath/$referencedFile"
            // Use name only for comparison if it's a relative path in the CUE
            val name = referencedFile.substringAfterLast('/')
            val list = source.list(parentPath)
            if (list.any { it.name == name }) {
                audioPath = p
            }
        }
        
        // 2. Fallback: Try common extensions with same name as .cue
        if (audioPath == null) {
            val base = cuePath.substringBeforeLast('.')
            val possibleExtensions = listOf("flac", "ape", "wav", "mp3", "m4a", "dsf", "dff")
            for (ext in possibleExtensions) {
                val p = "$base.$ext"
                val name = p.substringAfterLast('/')
                val list = source.list(parentPath)
                if (list.any { it.name == name }) {
                    audioPath = p
                    break
                }
            }
        }

        if (audioPath == null) return

        currentSource = source
        currentSourceConfig = sourceConfig
        currentFolderPath = cuePath.substringBeforeLast('/')
        
        val audioUri = source.getUri(audioPath)
        val coverUri = repository.findCover(source, currentFolderPath!!)

        val mediaItems = tracks.map { track ->
            repository.createCueMediaItem(
                fullAudioUri = audioUri,
                trackTitle = track.title,
                performer = track.performer,
                startTimeMs = track.startTimeMs,
                endTimeMs = track.endTimeMs,
                coverUri = coverUri,
                fileSize = 0
            )
        }

        player?.setMediaItems(mediaItems)
        
        // Find correct index to restore
        if (startingMediaId != null) {
            val index = mediaItems.indexOfFirst { it.mediaId == startingMediaId }
            if (index != -1) {
                player?.seekTo(index, positionMs)
            }
        } else {
            player?.seekTo(0, positionMs)
        }

        player?.prepare()
        if (playWhenReady) {
            player?.play()
        }

        // Save state immediately
        playbackPreferences?.savePlaybackState(sourceConfig, currentFolderPath!!, startingMediaId ?: cuePath, positionMs)

        kotlinx.coroutines.delay(1000)
        updateMetadata()
    }

    private suspend fun playFolderInternal(
        sourceConfig: SourceConfig, 
        path: String, 
        startingFileUri: String?, 
        positionMs: Long,
        playWhenReady: Boolean
    ) {
        val source = when (sourceConfig.type) {
            com.example.folderplayer.ui.browser.SourceType.LOCAL -> {
                com.example.folderplayer.data.source.WebDavAuthManager.clear()
                localSource
            }
            com.example.folderplayer.ui.browser.SourceType.WEBDAV -> {
                 com.example.folderplayer.data.source.WebDavAuthManager.setCredentials(sourceConfig.username, sourceConfig.password)
                 com.example.folderplayer.data.source.WebDavSource(sourceConfig.url, sourceConfig.username, sourceConfig.password)
            }
        }
        
        // Store current source for lyrics loading and persistence
        currentSource = source
        currentFolderPath = path
        currentSourceConfig = sourceConfig
        
        val items = repository.getMediaItemsInFolder(source, path)
        player?.setMediaItems(items)
        
        // Find the index of the starting file if provided
        if (startingFileUri != null) {
            val targetUri = source.getUri(startingFileUri).toString()
            val index = items.indexOfFirst { it.localConfiguration?.uri.toString() == targetUri || it.mediaId == startingFileUri }
            if (index != -1) {
                player?.seekTo(index, positionMs)
            }
        } else if (positionMs > 0) {
            player?.seekTo(0, positionMs)
        }
        
        player?.prepare()
        if (playWhenReady) {
            player?.play()
        }
        
        // High reliability seek for restoration: 
        if (positionMs > 0) {
            viewModelScope.launch(exceptionHandler) {
                // Wait for the player to transition from IDLE and start buffering/ready
                var attempts = 0
                while (player?.playbackState == Player.STATE_IDLE && attempts < 15) {
                    kotlinx.coroutines.delay(100)
                    attempts++
                }
                
                // Extra delay to ensure internal state is settled
                kotlinx.coroutines.delay(200)
                
                val index = if (startingFileUri != null) {
                    val targetUri = source.getUri(startingFileUri).toString()
                    items.indexOfFirst { it.localConfiguration?.uri.toString() == targetUri || it.mediaId == startingFileUri }
                } else 0
                
                if (index != -1) {
                    player?.seekTo(index, positionMs)
                }
            }
        }
        
        // Force metadata update after a short delay to ensure player is ready
        viewModelScope.launch(exceptionHandler) {
            kotlinx.coroutines.delay(1000)
            updateMetadata()
        }
        
        // Save state immediately
        playbackPreferences?.savePlaybackState(sourceConfig, path, startingFileUri, positionMs)
    }

    fun setCoverDisplaySize(size: String) {
        playbackPreferences?.saveCoverDisplaySize(size)
        _uiState.value = _uiState.value.copy(coverDisplaySize = size)
    }

    override fun onCleared() {
        mediaControllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }
}
