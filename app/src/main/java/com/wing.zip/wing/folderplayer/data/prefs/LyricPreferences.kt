package com.wing.folderplayer.data.prefs

import android.content.Context
import android.content.SharedPreferences

class LyricPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("lyric_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LYRIC_API_URL = "lyric_api_url"
        private const val DEFAULT_LYRIC_API_URL = "https://api.lrc.cx/lyrics"
    }

    fun getLyricApiUrl(): String {
        return prefs.getString(KEY_LYRIC_API_URL, DEFAULT_LYRIC_API_URL) ?: DEFAULT_LYRIC_API_URL
    }

    fun setLyricApiUrl(url: String) {
        prefs.edit().putString(KEY_LYRIC_API_URL, url).apply()
    }
}
